import { Group, Text } from "@mantine/core";
import { useEffect, useState } from "react";
import { allTransactionOverviewData} from "../../../utils/mockData";
import AnalyticsCard from "../../General/card";
import DateFilterMenu from "../../General/filterMenu";

const AllTransactionBox = () => {
  const [isMobile, setIsMobile] = useState(false);

  const checkScreenSize = () => {
    setIsMobile(window.innerWidth < 640);
  };

  useEffect(() => {
    checkScreenSize();

    window.addEventListener("resize", checkScreenSize);

    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  return (
    <main className="w-full h-auto overflow-auto px-3 sm:px-6 py-4 sm:py-8 rounded-lg bg-white">
      <header className="flex flex-row justify-between sm:items-center">
        <div className="flex flex-col mb-3 sm:mb-0 text-[#1D2739]">
          <Text size="xl" fw={600}>
          Card Transaction Overview
          </Text>

          {isMobile ? (
            <Text size="sm">
                {/* An overview of all requests */}
                </Text>
          ) : (
            <Text size="sm">
              {/* An overview of all requests */}
            </Text>
          )}
        </div>
        <Group className="mt-2 sm:mt-0">
          <DateFilterMenu
            defaultFilter="This Month"
            buttonVariant="subtle"
            buttonSize="md"
            showIconOnly="sm"
          />
        </Group>
      </header>
      <section className="flex flex-col sm:flex-row overflow-auto gap-6 md:gap-2 mt-5">
        {allTransactionOverviewData.map((card, index) => (
          <AnalyticsCard
            key={index}
            title={card.title}
            value={card.value}
            icon={
              <div>
                <img src={card.icon} alt={card.altText} />
              </div>
            }
            iconColor={card.iconColor}
            textColor={card.textColor}
            cardBgColor={card.cardBgColor}
            percentageValue={card.percentageValue}
            borderColor={card.borderColor}
          />
        ))}
        
      </section>
     
    </main>
  );
};

export default AllTransactionBox;
